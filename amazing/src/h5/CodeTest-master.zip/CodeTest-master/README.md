# CodeTest

> 个人平时学习、练习代码

**2017-05-14**
- [JavaScript/面试题/找出一个字符串里最长的那一个单词并打印出来.html](https://github.com/dunizb/CodeTest/blob/master/JavaScript/面试题/找出一个字符串里最长的那一个单词并打印出来.html)

**2017-05-07**
- [HTML&CSS/css3/background-clip:text.html](https://github.com/dunizb/CodeTest/blob/master/HTML%26CSS/css3/background-clip:text.html)

**2017-05-05**
- [jQuery/银行卡号4位空格.html](https://github.com/dunizb/CodeTest/blob/master/jQuery/%E9%93%B6%E8%A1%8C%E5%8D%A1%E5%8F%B74%E4%BD%8D%E7%A9%BA%E6%A0%BC.html)

**2017-05-02**
- Vue/dialog组件示例

**2017-03-18**
- Vue/全局注册select组件
- Vue/局部注册select组件
- Vue/全局注册select组件2

**2017-03-06**
- 移动Web&响应/licaibao-一个响应式页面实战

**2017-03-04**
- Javascript/字符串操作/隐藏任意个数字符串加星显示.html

**2017-02-10**
- HTML&CSS/css3/CSS3自定义滚动条样式 -webkit-scrollbar.html

**2017-01-18**
- test/小时分钟加减计算.html
- test/test.html

**2017-01-08**
- Vue/使用props传递数据.html
- Vue/Watcher 的使用.htm
- Vue.$watch 方法及取消观察.html
- Vue/Vue.extends.html