'use strick'

const react = require('react')

class MYUI extends react.Component {
    constructor(props){
        supper(props);
    }
}

render(){
    return (
        <div>hello gulp convert es2015.</div>
    )
}