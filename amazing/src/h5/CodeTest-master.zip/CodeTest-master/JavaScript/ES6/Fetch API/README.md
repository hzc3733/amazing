# Fetch API 简介

[Fetch API 简介](http://bubkoo.com/2015/05/08/introduction-to-fetch/)